<?php
//Variables globales del acceso a la base de datos (No accesible desde ficheros de ruta inferior)
$DB_SERVER = "localhost";
$DB_PORT = 3306;
$DB_USER = "root";
$DB_PASSWD = "";
$DB_SCHEMA = "mydb";
